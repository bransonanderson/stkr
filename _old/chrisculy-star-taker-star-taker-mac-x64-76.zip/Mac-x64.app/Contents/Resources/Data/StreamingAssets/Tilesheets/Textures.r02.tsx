<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Textures.r02" tilewidth="36" tileheight="36" tilecount="100" columns="10">
 <image source="Tileset-Textures.r02.sh.png" width="360" height="360"/>
</tileset>
