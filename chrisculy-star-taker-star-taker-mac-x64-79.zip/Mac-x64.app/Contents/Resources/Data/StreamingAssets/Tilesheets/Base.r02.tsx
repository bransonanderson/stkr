<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Base.r02" tilewidth="36" tileheight="36" tilecount="110" columns="11">
 <image source="Tileset-Base.r02.sh.png" width="396" height="360"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="4" x="0" y="0" width="36" height="36"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index">
   <object id="1" x="0" y="36">
    <polygon points="0,0 0,-36 36,0 0,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index">
   <object id="1" x="36" y="0">
    <polygon points="0,0 -36,36 0,36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="4">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 0,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index">
   <object id="1" x="0" y="36">
    <polygon points="0,0 36,0 36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="9">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 0,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="10">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="36" height="36"/>
  </objectgroup>
 </tile>
 <tile id="12">
  <objectgroup draworder="index">
   <object id="2" x="0" y="0">
    <polygon points="0,0 36,36 0,36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="13">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 0,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="14">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="15">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 0,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="16">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="17">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 0,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="20">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 0,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="21">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="22">
  <objectgroup draworder="index">
   <object id="2" x="0" y="0" width="36" height="36"/>
  </objectgroup>
 </tile>
 <tile id="23">
  <objectgroup draworder="index">
   <object id="2" x="0" y="0">
    <polygon points="0,0 36,36 0,36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="24">
  <objectgroup draworder="index">
   <object id="1" x="36" y="0">
    <polygon points="0,0 -36,36 0,36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="25">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="26">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 0,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="27">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="28">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 0,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="31">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 0,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="32">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="33">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="36" height="36"/>
  </objectgroup>
 </tile>
 <tile id="34">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0">
    <polygon points="0,0 36,36 0,36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="36">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 0,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index">
   <object id="1" x="0" y="36">
    <polygon points="0,0 0,-36 36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 0,-36 -36,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 0,-36"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="43">
  <objectgroup draworder="index">
   <object id="1" x="36" y="36">
    <polygon points="0,0 -36,0 -36,-36"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
